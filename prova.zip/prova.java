import java.util.Scanner;

class prova {
  public static void main(String[] args) {
    
    Scanner i = new Scanner(System.in);
    
    int ano;
    
    System.out.println("digite um ano para o programa informar se  o ano é bissexto ou não:");
    
    ano= i.nextInt();
    i.close();
    
    if(ano % 400==0){
        System.out.println(ano +" a ano informado e considerado bissexto" );
    }
    else if((ano % 4==0) && (ano % 100 !=0)){
       System.out.println(ano+ "é bissexto");
      
    }


else{System.out.println(ano+ "-não é bissexto");{
  
}

    }
    
  }
}